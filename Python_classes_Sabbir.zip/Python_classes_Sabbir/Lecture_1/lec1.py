""" My first class"""

Name = input("Enter the name: ")
print(Name)
age = input("Enter the age: ")
print(age)
name = input("Enter the name again: ")
print(name)
a=int(input("enter the first number: "))
b=int(input("enter the second number: "))
sum = a+b
print(sum)